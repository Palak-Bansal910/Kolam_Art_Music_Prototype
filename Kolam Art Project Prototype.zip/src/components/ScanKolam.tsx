import { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  Camera, 
  Upload, 
  Scan, 
  Eye, 
  Download, 
  Music, 
  Sparkles,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import type { Page } from '../App';

interface ScanKolamProps {
  onNavigate: (page: Page) => void;
}

interface ScanResult {
  detected: boolean;
  pattern: string;
  confidence: number;
  enhancedImage: string;
  musicMapping: {
    instrument: string;
    tempo: string;
    scale: string;
  };
}

export function ScanKolam({ onNavigate }: ScanKolamProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string);
        setScanResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleScan = async () => {
    if (!selectedImage) return;

    setIsScanning(true);
    setScanProgress(0);

    // Simulate AI scanning process
    const steps = [
      { progress: 20, message: "Preprocessing image..." },
      { progress: 40, message: "Detecting pattern structure..." },
      { progress: 60, message: "Analyzing geometric features..." },
      { progress: 80, message: "Reconstructing digital pattern..." },
      { progress: 100, message: "Generating music mapping..." }
    ];

    for (const step of steps) {
      await new Promise(resolve => setTimeout(resolve, 800));
      setScanProgress(step.progress);
    }

    // Mock scan result
    const mockResult: ScanResult = {
      detected: true,
      pattern: "Traditional Lotus Kolam",
      confidence: 92,
      enhancedImage: selectedImage, // In real app, this would be the enhanced version
      musicMapping: {
        instrument: "Veena",
        tempo: "Andante (72 BPM)",
        scale: "Raga Yaman"
      }
    };

    setScanResult(mockResult);
    setIsScanning(false);
  };

  const handleCameraCapture = () => {
    // In a real app, this would open camera interface
    alert("Camera functionality would be implemented here using WebRTC API");
  };

  const handleEnhanceWithMusic = () => {
    if (scanResult) {
      onNavigate('music');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-orange-50 to-emerald-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Scan Kolam</h1>
          <p className="text-lg text-gray-600">Transform physical Kolam art into digital experiences with AI recognition</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Upload Section */}
          <div className="space-y-6">
            <Card className="p-8 text-center border-2 border-dashed border-gray-300 hover:border-orange-400 transition-colors">
              {!selectedImage ? (
                <div className="space-y-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-full flex items-center justify-center mx-auto">
                    <Upload className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900">Upload Your Kolam</h3>
                  <p className="text-gray-600">
                    Upload a photo of your Kolam artwork for AI analysis and digital reconstruction
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      className="bg-gradient-to-r from-orange-500 to-red-500 text-white"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Choose File
                    </Button>
                    <Button
                      onClick={handleCameraCapture}
                      variant="outline"
                      className="border-2 border-emerald-500 text-emerald-700"
                    >
                      <Camera className="w-4 h-4 mr-2" />
                      Use Camera
                    </Button>
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="aspect-square max-w-sm mx-auto rounded-lg overflow-hidden">
                    <img 
                      src={selectedImage} 
                      alt="Uploaded Kolam" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex gap-2 justify-center">
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      variant="outline"
                      size="sm"
                    >
                      Change Image
                    </Button>
                    <Button
                      onClick={handleScan}
                      disabled={isScanning}
                      className="bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                    >
                      <Scan className="w-4 h-4 mr-2" />
                      {isScanning ? 'Scanning...' : 'Analyze Pattern'}
                    </Button>
                  </div>
                </div>
              )}
            </Card>

            {/* Scanning Progress */}
            {isScanning && (
              <Card className="p-6">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
                  <Sparkles className="w-5 h-5 mr-2 text-purple-600" />
                  AI Analysis in Progress
                </h3>
                <div className="space-y-4">
                  <Progress value={scanProgress} className="h-3" />
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">{scanProgress}%</div>
                    <div className="text-sm text-gray-600">Processing your Kolam pattern...</div>
                  </div>
                </div>
              </Card>
            )}

            {/* Tips */}
            <Card className="p-6 bg-orange-50 border-orange-200">
              <h3 className="font-semibold text-orange-900 mb-3">Tips for Best Results</h3>
              <ul className="text-sm text-orange-800 space-y-2">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Ensure good lighting and clear visibility of the pattern</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Capture the entire Kolam design within the frame</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Avoid shadows and reflections on the artwork</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Take the photo from directly above for best perspective</span>
                </li>
              </ul>
            </Card>
          </div>

          {/* Results Section */}
          <div className="space-y-6">
            {scanResult ? (
              <>
                {/* Scan Results */}
                <Card className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-900">Scan Results</h3>
                    <Badge className="bg-green-100 text-green-800">
                      <CheckCircle className="w-4 h-4 mr-1" />
                      Pattern Detected
                    </Badge>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700">Pattern Type</label>
                      <div className="text-lg font-semibold text-gray-900">{scanResult.pattern}</div>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-gray-700">Confidence Score</label>
                      <div className="flex items-center space-x-2">
                        <Progress value={scanResult.confidence} className="flex-1 h-2" />
                        <span className="text-sm font-medium text-gray-900">{scanResult.confidence}%</span>
                      </div>
                    </div>

                    {/* Enhanced Image Preview */}
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">Digital Reconstruction</label>
                      <div className="aspect-square rounded-lg overflow-hidden border-2 border-emerald-200">
                        <img 
                          src={scanResult.enhancedImage} 
                          alt="Enhanced Kolam" 
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                  </div>
                </Card>

                {/* Music Mapping */}
                <Card className="p-6 border-purple-200">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Music className="w-5 h-5 mr-2 text-purple-600" />
                    Music Mapping
                  </h3>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Suggested Instrument:</span>
                      <Badge variant="outline">{scanResult.musicMapping.instrument}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Tempo:</span>
                      <Badge variant="outline">{scanResult.musicMapping.tempo}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">Musical Scale:</span>
                      <Badge variant="outline">{scanResult.musicMapping.scale}</Badge>
                    </div>
                  </div>

                  <div className="mt-4 p-3 bg-purple-50 rounded-lg">
                    <p className="text-sm text-purple-800">
                      Based on the pattern analysis, we've mapped your Kolam to traditional Indian classical music scales and instruments for an authentic audio experience.
                    </p>
                  </div>
                </Card>

                {/* Actions */}
                <Card className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Next Steps</h3>
                  <div className="space-y-3">
                    <Button
                      onClick={handleEnhanceWithMusic}
                      className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                    >
                      <Music className="w-4 h-4 mr-2" />
                      Experience with Music
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full border-2 border-emerald-500 text-emerald-700"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download Enhanced Version
                    </Button>
                    <Button
                      onClick={() => onNavigate('create')}
                      variant="outline"
                      className="w-full"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      Edit in Create Mode
                    </Button>
                  </div>
                </Card>
              </>
            ) : (
              <Card className="p-8 text-center">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <AlertCircle className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No Results Yet</h3>
                <p className="text-gray-600 mb-6">
                  Upload an image of your Kolam artwork to see AI analysis results and digital reconstruction.
                </p>
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  className="bg-gradient-to-r from-orange-500 to-red-500 text-white"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Get Started
                </Button>
              </Card>
            )}
          </div>
        </div>

        {/* Example Gallery */}
        <div className="mt-12">
          <Card className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              Example Scan Results
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  title: "Lotus Petal Kolam",
                  confidence: 96,
                  instrument: "Veena",
                  image: "https://images.unsplash.com/photo-1703584347443-43e3c50a5a80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb2xhbSUyMHJhbmdvbGklMjB0cmFkaXRpb25hbCUyMGluZGlhbiUyMGFydHxlbnwxfHx8fDE3NTg2NDMwMjF8MA&ixlib=rb-4.1.0&q=80&w=1080"
                },
                {
                  title: "Geometric Star Pattern",
                  confidence: 89,
                  instrument: "Sitar",
                  image: "https://images.unsplash.com/photo-1571015691553-6f6bbd4ad1d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnZW9tZXRyaWMlMjBwYXR0ZXJucyUyMG1hbmRhbGElMjBzYWNyZWQlMjBnZW9tZXRyeXxlbnwxfHx8fDE3NTg2NDMwMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
                },
                {
                  title: "Traditional Peacock Design",
                  confidence: 94,
                  instrument: "Flute",
                  image: "https://images.unsplash.com/photo-1664427650948-edaa97ea4dd5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB0ZW1wbGUlMjBhcmNoaXRlY3R1cmUlMjBjdWx0dXJhbCUyMGhlcml0YWdlfGVufDF8fHx8MTc1ODY0MzAyM3ww&ixlib=rb-4.1.0&q=80&w=1080"
                }
              ].map((example, index) => (
                <div key={index} className="text-center">
                  <div className="aspect-square rounded-lg overflow-hidden mb-3">
                    <ImageWithFallback
                      src={example.image}
                      alt={example.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-1">{example.title}</h4>
                  <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                    <Badge variant="outline" className="text-xs">{example.confidence}% match</Badge>
                    <Badge variant="outline" className="text-xs">{example.instrument}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}