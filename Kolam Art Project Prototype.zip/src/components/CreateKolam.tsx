import { useState, useRef, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Slider } from './ui/slider';
import { Badge } from './ui/badge';
import { 
  Palette, 
  Undo, 
  Redo, 
  Save, 
  Download, 
  Music, 
  Grid, 
  FlipHorizontal,
  Circle,
  Brush,
  Eraser,
  Volume2,
  VolumeX
} from 'lucide-react';
import { KolamCanvas } from './KolamCanvas';
import type { Page } from '../App';

interface CreateKolamProps {
  onNavigate: (page: Page) => void;
}

const textures = [
  { id: 'chalk', name: 'Chalk', color: '#ffffff', preview: '#f3f4f6' },
  { id: 'rangoli-red', name: 'Rangoli Red', color: '#dc2626', preview: '#dc2626' },
  { id: 'rangoli-yellow', name: 'Rangoli Yellow', color: '#fbbf24', preview: '#fbbf24' },
  { id: 'rangoli-green', name: 'Rangoli Green', color: '#059669', preview: '#059669' },
  { id: 'rangoli-blue', name: 'Rangoli Blue', color: '#2563eb', preview: '#2563eb' },
  { id: 'rangoli-purple', name: 'Rangoli Purple', color: '#7c3aed', preview: '#7c3aed' },
  { id: 'neon-orange', name: 'Neon Orange', color: '#ff6b35', preview: '#ff6b35' },
  { id: 'neon-pink', name: 'Neon Pink', color: '#ec4899', preview: '#ec4899' },
];

const instruments = [
  { id: 'veena', name: 'Veena', icon: '🎻' },
  { id: 'tabla', name: 'Tabla', icon: '🥁' },
  { id: 'flute', name: 'Flute', icon: '🪈' },
  { id: 'sitar', name: 'Sitar', icon: '🎸' },
  { id: 'electronic', name: 'Electronic', icon: '🎹' },
];

export function CreateKolam({ onNavigate }: CreateKolamProps) {
  const [selectedTool, setSelectedTool] = useState<'dot' | 'line' | 'brush' | 'eraser'>('dot');
  const [selectedTexture, setSelectedTexture] = useState(textures[0]);
  const [brushSize, setBrushSize] = useState([8]);
  const [showGrid, setShowGrid] = useState(true);
  const [symmetryMode, setSymmetryMode] = useState(false);
  const [selectedInstrument, setSelectedInstrument] = useState(instruments[0]);
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [canvasData, setCanvasData] = useState<any>(null);

  const handleSave = () => {
    // Mock save functionality
    console.log('Saving Kolam...', canvasData);
    // In a real app, this would save to localStorage or send to backend
  };

  const handleExport = () => {
    // Mock export functionality  
    console.log('Exporting Kolam...');
    // In a real app, this would generate and download an image file
  };

  const handleUndo = () => {
    console.log('Undo action');
  };

  const handleRedo = () => {
    console.log('Redo action');
  };

  const playMusicalNote = (x: number, y: number) => {
    if (!musicEnabled) return;
    
    // Mock musical feedback - in a real app, this would play actual sounds
    console.log(`Playing ${selectedInstrument.name} note at position (${x}, ${y})`);
    
    // Visual feedback for musical interaction
    const note = document.createElement('div');
    note.className = 'fixed pointer-events-none text-2xl animate-ping';
    note.style.left = `${x}px`;
    note.style.top = `${y}px`;
    note.textContent = '♪';
    document.body.appendChild(note);
    
    setTimeout(() => {
      document.body.removeChild(note);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-orange-50 to-emerald-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Create Your Kolam</h1>
          <p className="text-lg text-gray-600">Express your creativity with interactive tools and musical feedback</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Tool Panel */}
          <div className="lg:col-span-1 space-y-6">
            {/* Drawing Tools */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4 text-gray-900">Drawing Tools</h3>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant={selectedTool === 'dot' ? 'default' : 'outline'}
                  onClick={() => setSelectedTool('dot')}
                  className="h-12"
                >
                  <Circle className="w-4 h-4 mr-2" />
                  Dots
                </Button>
                <Button
                  variant={selectedTool === 'line' ? 'default' : 'outline'}
                  onClick={() => setSelectedTool('line')}
                  className="h-12"
                >
                  <div className="w-4 h-0 border-t-2 border-current mr-2"></div>
                  Lines
                </Button>
                <Button
                  variant={selectedTool === 'brush' ? 'default' : 'outline'}
                  onClick={() => setSelectedTool('brush')}
                  className="h-12"
                >
                  <Brush className="w-4 h-4 mr-2" />
                  Brush
                </Button>
                <Button
                  variant={selectedTool === 'eraser' ? 'default' : 'outline'}
                  onClick={() => setSelectedTool('eraser')}
                  className="h-12"
                >
                  <Eraser className="w-4 h-4 mr-2" />
                  Eraser
                </Button>
              </div>

              {/* Brush Size */}
              <div className="mt-6">
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Brush Size: {brushSize[0]}px
                </label>
                <Slider
                  value={brushSize}
                  onValueChange={setBrushSize}
                  max={50}
                  min={2}
                  step={2}
                  className="w-full"
                />
              </div>
            </Card>

            {/* Color Palette */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4 text-gray-900">Color Palette</h3>
              <div className="grid grid-cols-2 gap-2">
                {textures.map((texture) => (
                  <Button
                    key={texture.id}
                    variant={selectedTexture.id === texture.id ? 'default' : 'outline'}
                    onClick={() => setSelectedTexture(texture)}
                    className="h-12 p-2"
                  >
                    <div
                      className="w-4 h-4 rounded-full mr-2 border border-gray-300"
                      style={{ backgroundColor: texture.preview }}
                    ></div>
                    <span className="text-xs">{texture.name}</span>
                  </Button>
                ))}
              </div>
            </Card>

            {/* Canvas Options */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4 text-gray-900">Canvas Options</h3>
              <div className="space-y-3">
                <Button
                  variant={showGrid ? 'default' : 'outline'}
                  onClick={() => setShowGrid(!showGrid)}
                  className="w-full justify-start"
                >
                  <Grid className="w-4 h-4 mr-2" />
                  {showGrid ? 'Hide Grid' : 'Show Grid'}
                </Button>
                <Button
                  variant={symmetryMode ? 'default' : 'outline'}
                  onClick={() => setSymmetryMode(!symmetryMode)}
                  className="w-full justify-start"
                >
                  <FlipHorizontal className="w-4 h-4 mr-2" />
                  {symmetryMode ? 'Disable Symmetry' : 'Enable Symmetry'}
                </Button>
              </div>
            </Card>

            {/* Music Integration */}
            <Card className="p-6 border-purple-200">
              <h3 className="text-lg font-semibold mb-4 text-gray-900 flex items-center">
                <Music className="w-5 h-5 mr-2 text-purple-600" />
                Musical Kolam
              </h3>
              
              <div className="space-y-4">
                <Button
                  variant={musicEnabled ? 'default' : 'outline'}
                  onClick={() => setMusicEnabled(!musicEnabled)}
                  className="w-full justify-start"
                >
                  {musicEnabled ? (
                    <Volume2 className="w-4 h-4 mr-2" />
                  ) : (
                    <VolumeX className="w-4 h-4 mr-2" />
                  )}
                  {musicEnabled ? 'Music Enabled' : 'Music Disabled'}
                </Button>

                {musicEnabled && (
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Instrument
                    </label>
                    <div className="grid grid-cols-1 gap-2">
                      {instruments.map((instrument) => (
                        <Button
                          key={instrument.id}
                          variant={selectedInstrument.id === instrument.id ? 'default' : 'outline'}
                          onClick={() => setSelectedInstrument(instrument)}
                          className="justify-start text-sm"
                        >
                          <span className="mr-2">{instrument.icon}</span>
                          {instrument.name}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {musicEnabled && (
                <div className="mt-4 p-3 bg-purple-50 rounded-lg">
                  <p className="text-sm text-purple-800">
                    <strong>Musical Mode:</strong> Each line you draw will produce a sound from the selected instrument, creating a unique musical composition!
                  </p>
                </div>
              )}
            </Card>
          </div>

          {/* Canvas Area */}
          <div className="lg:col-span-3">
            <Card className="p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Badge variant="outline" className="text-sm">
                    Tool: {selectedTool.charAt(0).toUpperCase() + selectedTool.slice(1)}
                  </Badge>
                  <Badge variant="outline" className="text-sm">
                    Color: {selectedTexture.name}
                  </Badge>
                  {symmetryMode && (
                    <Badge className="bg-purple-100 text-purple-800">
                      Symmetry Mode
                    </Badge>
                  )}
                </div>

                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" onClick={handleUndo}>
                    <Undo className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleRedo}>
                    <Redo className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleSave}>
                    <Save className="w-4 h-4 mr-2" />
                    Save
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleExport}>
                    <Download className="w-4 h-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>

              {/* Canvas Component */}
              <div className="bg-white rounded-lg border-2 border-gray-200 overflow-hidden">
                <KolamCanvas
                  tool={selectedTool}
                  color={selectedTexture.color}
                  brushSize={brushSize[0]}
                  showGrid={showGrid}
                  symmetryMode={symmetryMode}
                  onDrawAction={playMusicalNote}
                  musicEnabled={musicEnabled}
                />
              </div>

              {/* Help Text */}
              <div className="mt-4 p-4 bg-orange-50 rounded-lg">
                <h4 className="font-medium text-orange-900 mb-2">Getting Started:</h4>
                <ul className="text-sm text-orange-800 space-y-1">
                  <li>• Start with dots to create your foundation grid</li>
                  <li>• Use lines to connect dots and create patterns</li>
                  <li>• Enable symmetry mode for perfectly balanced designs</li>
                  <li>• Listen to the musical feedback as you draw</li>
                  <li>• Save your work and share with the community</li>
                </ul>
              </div>
            </Card>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-8 text-center">
          <div className="inline-flex space-x-4">
            <Button
              onClick={() => onNavigate('gallery')}
              variant="outline"
              className="border-2 border-emerald-500 text-emerald-700 px-8 py-3"
              size="lg"
            >
              View Gallery
            </Button>
            <Button
              onClick={() => onNavigate('music')}
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-3"
              size="lg"
            >
              <Music className="w-5 h-5 mr-2" />
              Experience Music Mode
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}