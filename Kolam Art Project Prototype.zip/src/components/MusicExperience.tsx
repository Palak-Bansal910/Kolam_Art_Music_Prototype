import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Slider } from './ui/slider';
import { Badge } from './ui/badge';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  SkipForward, 
  SkipBack,
  Shuffle,
  Repeat,
  Music,
  Waves,
  Settings
} from 'lucide-react';
import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import type { Page } from '../App';

interface MusicExperienceProps {
  onNavigate: (page: Page) => void;
}

interface KolamPattern {
  id: string;
  name: string;
  description: string;
  instrument: string;
  tempo: string;
  scale: string;
  duration: string;
  image: string;
  complexity: 'Simple' | 'Moderate' | 'Complex';
}

const kolamPatterns: KolamPattern[] = [
  {
    id: '1',
    name: 'Lotus Bloom',
    description: 'A serene pattern representing spiritual awakening',
    instrument: 'Veena',
    tempo: 'Andante (72 BPM)',
    scale: 'Raga Yaman',
    duration: '3:24',
    image: 'https://images.unsplash.com/photo-1703584347443-43e3c50a5a80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb2xhbSUyMHJhbmdvbGklMjB0cmFkaXRpb25hbCUyMGluZGlhbiUyMGFydHxlbnwxfHx8fDE3NTg2NDMwMjF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    complexity: 'Moderate'
  },
  {
    id: '2',
    name: 'Cosmic Mandala',
    description: 'Geometric patterns representing universal harmony',
    instrument: 'Sitar',
    tempo: 'Allegro (120 BPM)',
    scale: 'Raga Bhairav',
    duration: '4:12',
    image: 'https://images.unsplash.com/photo-1571015691553-6f6bbd4ad1d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnZW9tZXRyaWMlMjBwYXR0ZXJucyUyMG1hbmRhbGElMjBzYWNyZWQlMjBnZW9tZXRyeXxlbnwxfHx8fDE3NTg2NDMwMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    complexity: 'Complex'
  },
  {
    id: '3',
    name: 'Peacock Dance',
    description: 'Graceful curves inspired by the divine bird',
    instrument: 'Flute',
    tempo: 'Moderato (96 BPM)',
    scale: 'Raga Kafi',
    duration: '2:48',
    image: 'https://images.unsplash.com/photo-1664427650948-edaa97ea4dd5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB0ZW1wbGUlMjBhcmNoaXRlY3R1cmUlMjBjdWx0dXJhbCUyMGhlcml0YWdlfGVufDF8fHx8MTc1ODY0MzAyM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    complexity: 'Simple'
  },
  {
    id: '4',
    name: 'Sacred Geometry',
    description: 'Mathematical perfection in musical form',
    instrument: 'Tabla + Tanpura',
    tempo: 'Largo (60 BPM)',
    scale: 'Raga Malkauns',
    duration: '5:36',
    image: 'https://images.unsplash.com/photo-1643098979608-1b22614abe88?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBjbGFzc2ljYWwlMjBtdXNpYyUyMGluc3RydW1lbnRzJTIwdmVlbmElMjBzaXRhcnxlbnwxfHx8fDE3NTg2NDMwMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    complexity: 'Complex'
  }
];

export function MusicExperience({ onNavigate }: MusicExperienceProps) {
  const [selectedPattern, setSelectedPattern] = useState(kolamPatterns[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState([75]);
  const [isMuted, setIsMuted] = useState(false);
  const [visualizationMode, setVisualizationMode] = useState<'pattern' | 'waveform' | 'geometric'>('pattern');

  // Mock audio duration and progress
  const totalDuration = 240; // 4 minutes in seconds

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime(prev => {
          if (prev >= totalDuration) {
            setIsPlaying(false);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, totalDuration]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getComplexityColor = (complexity: string) => {
    switch (complexity) {
      case 'Simple': return 'bg-green-100 text-green-800';
      case 'Moderate': return 'bg-yellow-100 text-yellow-800';
      case 'Complex': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handlePatternSelect = (pattern: KolamPattern) => {
    setSelectedPattern(pattern);
    setCurrentTime(0);
    setIsPlaying(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Kolam Music Experience</h1>
          <p className="text-lg text-gray-600">Watch Kolam patterns come alive through traditional Indian classical music</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Pattern Selection */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4 text-gray-900">Select Pattern</h2>
              <div className="space-y-3">
                {kolamPatterns.map((pattern) => (
                  <div
                    key={pattern.id}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedPattern.id === pattern.id
                        ? 'border-purple-500 bg-purple-50'
                        : 'border-gray-200 hover:border-purple-300'
                    }`}
                    onClick={() => handlePatternSelect(pattern)}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 rounded-lg overflow-hidden">
                        <ImageWithFallback
                          src={pattern.image}
                          alt={pattern.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">{pattern.name}</h3>
                        <p className="text-sm text-gray-600">{pattern.instrument}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge className={getComplexityColor(pattern.complexity)} size="sm">
                            {pattern.complexity}
                          </Badge>
                          <span className="text-xs text-gray-500">{pattern.duration}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Visualization Controls */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4 text-gray-900">Visualization Mode</h3>
              <div className="space-y-2">
                {[
                  { id: 'pattern', label: 'Animated Pattern', icon: '🎨' },
                  { id: 'waveform', label: 'Audio Waveform', icon: '〰️' },
                  { id: 'geometric', label: 'Geometric Sync', icon: '⬢' }
                ].map((mode) => (
                  <Button
                    key={mode.id}
                    variant={visualizationMode === mode.id ? 'default' : 'outline'}
                    onClick={() => setVisualizationMode(mode.id as any)}
                    className="w-full justify-start"
                  >
                    <span className="mr-2">{mode.icon}</span>
                    {mode.label}
                  </Button>
                ))}
              </div>
            </Card>
          </div>

          {/* Main Experience Area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Current Pattern Info */}
            <Card className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">{selectedPattern.name}</h2>
                  <p className="text-gray-600 mb-4">{selectedPattern.description}</p>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500">Instrument:</span>
                      <div className="font-medium">{selectedPattern.instrument}</div>
                    </div>
                    <div>
                      <span className="text-gray-500">Tempo:</span>
                      <div className="font-medium">{selectedPattern.tempo}</div>
                    </div>
                    <div>
                      <span className="text-gray-500">Scale:</span>
                      <div className="font-medium">{selectedPattern.scale}</div>
                    </div>
                    <div>
                      <span className="text-gray-500">Complexity:</span>
                      <Badge className={getComplexityColor(selectedPattern.complexity)}>
                        {selectedPattern.complexity}
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>
            </Card>

            {/* Visualization Area */}
            <Card className="p-8">
              <div className="aspect-video bg-gradient-to-br from-purple-100 to-pink-100 rounded-xl flex items-center justify-center mb-6 overflow-hidden">
                <KolamVisualization 
                  pattern={selectedPattern}
                  isPlaying={isPlaying}
                  currentTime={currentTime}
                  mode={visualizationMode}
                />
              </div>

              {/* Audio Controls */}
              <div className="space-y-4">
                {/* Progress Bar */}
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>{formatTime(currentTime)}</span>
                    <span>{selectedPattern.duration}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(currentTime / totalDuration) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Playback Controls */}
                <div className="flex items-center justify-center space-x-4">
                  <Button variant="outline" size="sm">
                    <SkipBack className="w-4 h-4" />
                  </Button>
                  
                  <Button
                    onClick={handlePlayPause}
                    className="bg-gradient-to-r from-purple-500 to-pink-500 text-white w-12 h-12 rounded-full"
                  >
                    {isPlaying ? (
                      <Pause className="w-6 h-6" />
                    ) : (
                      <Play className="w-6 h-6" />
                    )}
                  </Button>
                  
                  <Button variant="outline" size="sm">
                    <SkipForward className="w-4 h-4" />
                  </Button>
                  
                  <Button variant="outline" size="sm">
                    <Shuffle className="w-4 h-4" />
                  </Button>
                  
                  <Button variant="outline" size="sm">
                    <Repeat className="w-4 h-4" />
                  </Button>
                </div>

                {/* Volume Control */}
                <div className="flex items-center space-x-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsMuted(!isMuted)}
                  >
                    {isMuted || volume[0] === 0 ? (
                      <VolumeX className="w-4 h-4" />
                    ) : (
                      <Volume2 className="w-4 h-4" />
                    )}
                  </Button>
                  
                  <div className="flex-1 max-w-32">
                    <Slider
                      value={isMuted ? [0] : volume}
                      onValueChange={(value) => {
                        setVolume(value);
                        setIsMuted(value[0] === 0);
                      }}
                      max={100}
                      step={1}
                      className="w-full"
                    />
                  </div>
                  
                  <span className="text-sm text-gray-600 w-8">
                    {isMuted ? 0 : volume[0]}
                  </span>
                </div>
              </div>
            </Card>

            {/* Experience Features */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="p-6 text-center">
                <Waves className="w-12 h-12 mx-auto mb-4 text-purple-600" />
                <h3 className="font-semibold text-gray-900 mb-2">Real-time Sync</h3>
                <p className="text-sm text-gray-600">
                  Watch patterns animate in perfect harmony with the musical composition
                </p>
              </Card>
              
              <Card className="p-6 text-center">
                <Settings className="w-12 h-12 mx-auto mb-4 text-pink-600" />
                <h3 className="font-semibold text-gray-900 mb-2">Customizable</h3>
                <p className="text-sm text-gray-600">
                  Adjust visualization modes, tempo, and instruments to your preference
                </p>
              </Card>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-12 text-center">
          <div className="inline-flex space-x-4">
            <Button
              onClick={() => onNavigate('create')}
              className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-8 py-3"
              size="lg"
            >
              Create Your Own
            </Button>
            <Button
              onClick={() => onNavigate('gallery')}
              variant="outline"
              className="border-2 border-purple-500 text-purple-700 px-8 py-3"
              size="lg"
            >
              <Music className="w-5 h-5 mr-2" />
              Explore Gallery
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

function KolamVisualization({ 
  pattern, 
  isPlaying, 
  currentTime, 
  mode 
}: { 
  pattern: KolamPattern; 
  isPlaying: boolean; 
  currentTime: number; 
  mode: string; 
}) {
  const renderVisualization = () => {
    switch (mode) {
      case 'waveform':
        return <WaveformVisualization isPlaying={isPlaying} />;
      case 'geometric':
        return <GeometricVisualization isPlaying={isPlaying} currentTime={currentTime} />;
      default:
        return <PatternVisualization pattern={pattern} isPlaying={isPlaying} currentTime={currentTime} />;
    }
  };

  return (
    <div className="w-full h-full flex items-center justify-center">
      {renderVisualization()}
    </div>
  );
}

function PatternVisualization({ pattern, isPlaying, currentTime }: { pattern: KolamPattern; isPlaying: boolean; currentTime: number }) {
  return (
    <div className="relative w-full h-full">
      <div className="absolute inset-0 flex items-center justify-center">
        <ImageWithFallback
          src={pattern.image}
          alt={pattern.name}
          className="max-w-full max-h-full object-contain rounded-lg opacity-70"
        />
      </div>
      
      {/* Animated overlay */}
      <div className="absolute inset-0 flex items-center justify-center">
        <svg width="300" height="300" className="absolute">
          {/* Animated circles representing sound waves */}
          {isPlaying && (
            <>
              <motion.circle
                cx="150"
                cy="150"
                r="50"
                fill="none"
                stroke="rgba(168, 85, 247, 0.4)"
                strokeWidth="2"
                animate={{
                  r: [50, 120, 50],
                  opacity: [0.8, 0, 0.8]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
              <motion.circle
                cx="150"
                cy="150"
                r="30"
                fill="none"
                stroke="rgba(236, 72, 153, 0.6)"
                strokeWidth="3"
                animate={{
                  r: [30, 80, 30],
                  opacity: [1, 0, 1]
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 0.5
                }}
              />
            </>
          )}
        </svg>
      </div>
    </div>
  );
}

function WaveformVisualization({ isPlaying }: { isPlaying: boolean }) {
  const bars = Array.from({ length: 32 }, (_, i) => i);

  return (
    <div className="flex items-center justify-center space-x-2 h-32">
      {bars.map((bar) => (
        <motion.div
          key={bar}
          className="w-3 bg-gradient-to-t from-purple-500 to-pink-500 rounded-t-sm"
          animate={isPlaying ? {
            height: [20, Math.random() * 80 + 20, 20]
          } : {
            height: 20
          }}
          transition={{
            duration: 1 + Math.random(),
            repeat: isPlaying ? Infinity : 0,
            ease: "easeInOut"
          }}
        />
      ))}
    </div>
  );
}

function GeometricVisualization({ isPlaying, currentTime }: { isPlaying: boolean; currentTime: number }) {
  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <svg width="300" height="300">
        {/* Rotating geometric patterns */}
        <motion.g
          animate={isPlaying ? { rotate: 360 } : { rotate: 0 }}
          transition={{ duration: 8, repeat: isPlaying ? Infinity : 0, ease: "linear" }}
          style={{ transformOrigin: "150px 150px" }}
        >
          {Array.from({ length: 6 }, (_, i) => (
            <motion.polygon
              key={i}
              points="150,50 200,100 150,150 100,100"
              fill="none"
              stroke={`hsl(${280 + i * 20}, 70%, 60%)`}
              strokeWidth="2"
              transform={`rotate(${i * 60} 150 150)`}
              animate={isPlaying ? {
                opacity: [0.3, 1, 0.3]
              } : {
                opacity: 0.3
              }}
              transition={{
                duration: 2,
                repeat: isPlaying ? Infinity : 0,
                delay: i * 0.2
              }}
            />
          ))}
        </motion.g>
      </svg>
    </div>
  );
}