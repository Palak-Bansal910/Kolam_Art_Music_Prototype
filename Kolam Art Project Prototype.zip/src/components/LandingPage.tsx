import { Button } from './ui/button';
import { Card } from './ui/card';
import { Play, BookOpen, Palette, Music, Sparkles } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { AnimatedKolamPattern } from './AnimatedKolamPattern';
import type { Page } from '../App';

interface LandingPageProps {
  onNavigate: (page: Page) => void;
}

export function LandingPage({ onNavigate }: LandingPageProps) {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-white via-orange-50 to-emerald-50" />
        
        {/* Animated Background Pattern */}
        <div className="absolute inset-0">
          <AnimatedKolamPattern />
        </div>

        <div className="relative z-10 text-center max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-gradient-to-r from-orange-100 to-emerald-100 text-orange-800 mb-6">
              <Sparkles className="w-4 h-4 mr-2" />
              <span className="text-sm font-medium">Where Tradition Meets Technology</span>
            </div>
          </div>

          <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-br from-orange-600 via-red-700 to-emerald-600 bg-clip-text text-transparent">
            Kolam
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-700 mb-12 max-w-2xl mx-auto">
            Discover the sacred geometry of Kolam art through interactive learning, 
            creative expression, and musical harmony.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              onClick={() => onNavigate('learn')}
              className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white px-8 py-4 text-lg"
              size="lg"
            >
              <BookOpen className="w-5 h-5 mr-2" />
              Start Learning
            </Button>
            
            <Button
              onClick={() => onNavigate('create')}
              variant="outline"
              className="border-2 border-emerald-500 text-emerald-700 hover:bg-emerald-50 px-8 py-4 text-lg"
              size="lg"
            >
              <Palette className="w-5 h-5 mr-2" />
              Create Your Kolam
            </Button>
            
            <Button
              onClick={() => onNavigate('music')}
              variant="outline"
              className="border-2 border-orange-500 text-orange-700 hover:bg-orange-50 px-8 py-4 text-lg"
              size="lg"
            >
              <Music className="w-5 h-5 mr-2" />
              Experience with Music
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Immerse Yourself in Kolam Culture
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From learning traditional patterns to creating musical masterpieces, 
              explore every aspect of this ancient art form.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="p-8 hover:shadow-xl transition-shadow duration-300 border-orange-200">
              <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center mb-6">
                <BookOpen className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-semibold mb-4 text-gray-900">Interactive Learning</h3>
              <p className="text-gray-600 mb-6">
                Step-by-step tutorials with cultural context, voice narration, and traditional music accompaniment.
              </p>
              <Button 
                onClick={() => onNavigate('learn')}
                className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white"
              >
                Start Learning
              </Button>
            </Card>

            <Card className="p-8 hover:shadow-xl transition-shadow duration-300 border-emerald-200">
              <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-2xl flex items-center justify-center mb-6">
                <Palette className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-semibold mb-4 text-gray-900">Creative Canvas</h3>
              <p className="text-gray-600 mb-6">
                Design your own Kolam patterns with digital tools, symmetry assistance, and musical feedback.
              </p>
              <Button 
                onClick={() => onNavigate('create')}
                className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 text-white"
              >
                Create Art
              </Button>
            </Card>

            <Card className="p-8 hover:shadow-xl transition-shadow duration-300 border-purple-200">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mb-6">
                <Music className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-semibold mb-4 text-gray-900">Musical Harmony</h3>
              <p className="text-gray-600 mb-6">
                Experience Kolam patterns as music with traditional instruments and visual synchronization.
              </p>
              <Button 
                onClick={() => onNavigate('music')}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white"
              >
                Experience Music
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Cultural Heritage Section */}
      <section className="py-20 bg-gradient-to-br from-orange-50 to-emerald-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Ancient Art, Modern Expression
              </h2>
              <p className="text-lg text-gray-700 mb-6">
                Kolam is more than art—it's a meditation, a mathematical puzzle, and a cultural bridge. 
                Our platform preserves these traditions while making them accessible to a new generation.
              </p>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-gradient-to-br from-orange-500 to-red-500 rounded-full flex-shrink-0 mt-1"></div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Sacred Geometry</h4>
                    <p className="text-gray-600">Explore the mathematical beauty hidden in traditional patterns</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-full flex-shrink-0 mt-1"></div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Cultural Stories</h4>
                    <p className="text-gray-600">Learn the meaning and mythology behind each design</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex-shrink-0 mt-1"></div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Musical Expression</h4>
                    <p className="text-gray-600">Transform visual patterns into melodic experiences</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1703584347443-43e3c50a5a80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb2xhbSUyMHJhbmdvbGklMjB0cmFkaXRpb25hbCUyMGluZGlhbiUyMGFydHxlbnwxfHx8fDE3NTg2NDMwMjF8MA&ixlib=rb-4.1.0&q=80&w=1080"
                  alt="Traditional Kolam Art"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -top-6 -right-6 w-20 h-20 bg-gradient-to-br from-orange-400 to-red-500 rounded-full opacity-20"></div>
              <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full opacity-20"></div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-orange-600 via-red-600 to-emerald-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white mb-6">
            Begin Your Kolam Journey Today
          </h2>
          <p className="text-xl text-orange-100 mb-8">
            Join thousands of artists, learners, and culture enthusiasts in preserving and reimagining this beautiful tradition.
          </p>
          <Button
            onClick={() => onNavigate('challenge')}
            className="bg-white text-orange-600 hover:bg-orange-50 px-8 py-4 text-lg font-semibold"
            size="lg"
          >
            <Play className="w-5 h-5 mr-2" />
            Try Today's Challenge
          </Button>
        </div>
      </section>
    </div>
  );
}