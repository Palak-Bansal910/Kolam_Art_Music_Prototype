import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Filter, 
  Search, 
  Grid3X3, 
  List,
  Trophy,
  Clock,
  User,
  Music,
  Eye,
  Download
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import type { Page } from '../App';

interface GalleryProps {
  onNavigate: (page: Page) => void;
}

interface KolamArt {
  id: string;
  title: string;
  artist: string;
  description: string;
  category: 'Traditional' | 'Musical' | 'Community' | 'Challenge';
  image: string;
  likes: number;
  comments: number;
  createdAt: string;
  isLiked: boolean;
  hasMusic: boolean;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  tags: string[];
}

const mockGalleryItems: KolamArt[] = [
  {
    id: '1',
    title: 'Sacred Lotus Mandala',
    artist: 'Priya Sharma',
    description: 'A traditional lotus pattern with 108 petals, representing spiritual enlightenment',
    category: 'Traditional',
    image: 'https://images.unsplash.com/photo-1703584347443-43e3c50a5a80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb2xhbSUyMHJhbmdvbGklMjB0cmFkaXRpb25hbCUyMGluZGlhbiUyMGFydHxlbnwxfHx8fDE3NTg2NDMwMjF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    likes: 342,
    comments: 28,
    createdAt: '2 days ago',
    isLiked: false,
    hasMusic: true,
    difficulty: 'Advanced',
    tags: ['lotus', 'mandala', 'spiritual', 'traditional']
  },
  {
    id: '2',
    title: 'Geometric Harmony',
    artist: 'Arjun Patel',
    description: 'Modern interpretation using sacred geometry principles',
    category: 'Musical',
    image: 'https://images.unsplash.com/photo-1571015691553-6f6bbd4ad1d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnZW9tZXRyaWMlMjBwYXR0ZXJucyUyMG1hbmRhbGElMjBzYWNyZWQlMjBnZW9tZXRyeXxlbnwxfHx8fDE3NTg2NDMwMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    likes: 156,
    comments: 15,
    createdAt: '5 days ago',
    isLiked: true,
    hasMusic: true,
    difficulty: 'Intermediate',
    tags: ['geometric', 'modern', 'harmony', 'music']
  },
  {
    id: '3',
    title: 'Peacock Dance',
    artist: 'Meera Krishna',
    description: 'Graceful curves inspired by the national bird of India',
    category: 'Community',
    image: 'https://images.unsplash.com/photo-1664427650948-edaa97ea4dd5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB0ZW1wbGUlMjBhcmNoaXRlY3R1cmUlMjBjdWx0dXJhbCUyMGhlcml0YWdlfGVufDF8fHx8MTc1ODY0MzAyM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    likes: 289,
    comments: 42,
    createdAt: '1 week ago',
    isLiked: false,
    hasMusic: false,
    difficulty: 'Beginner',
    tags: ['peacock', 'nature', 'curves', 'graceful']
  },
  {
    id: '4',
    title: 'Veena Vibes',
    artist: 'Classical_Fusion',
    description: 'Musical Kolam that plays a beautiful veena melody',
    category: 'Musical',
    image: 'https://images.unsplash.com/photo-1643098979608-1b22614abe88?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBjbGFzc2ljYWwlMjBtdXNpYyUyMGluc3RydW1lbnRzJTIwdmVlbmElMjBzaXRhcnxlbnwxfHx8fDE3NTg2NDMwMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    likes: 498,
    comments: 67,
    createdAt: '3 days ago',
    isLiked: true,
    hasMusic: true,
    difficulty: 'Advanced',
    tags: ['veena', 'music', 'classical', 'melody']
  },
  {
    id: '5',
    title: 'Daily Challenge Winner',
    artist: 'Kolam_Master_2025',
    description: 'Winner of Day 15 challenge - Floral Symmetry',
    category: 'Challenge',
    image: 'https://images.unsplash.com/photo-1703584347443-43e3c50a5a80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb2xhbSUyMHJhbmdvbGklMjB0cmFkaXRpb25hbCUyMGluZGlhbiUyMGFydHxlbnwxfHx8fDE3NTg2NDMwMjF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    likes: 623,
    comments: 89,
    createdAt: '1 day ago',
    isLiked: false,
    hasMusic: false,
    difficulty: 'Intermediate',
    tags: ['challenge', 'winner', 'floral', 'symmetry']
  },
  {
    id: '6',
    title: 'Sunrise Mandala',
    artist: 'Dawn_Artist',
    description: 'Inspired by the first light of dawn',
    category: 'Traditional',
    image: 'https://images.unsplash.com/photo-1571015691553-6f6bbd4ad1d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnZW9tZXRyaWMlMjBwYXR0ZXJucyUyMG1hbmRhbGElMjBzYWNyZWQlMjBnZW9tZXRyeXxlbnwxfHx8fDE3NTg2NDMwMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    likes: 234,
    comments: 19,
    createdAt: '4 days ago',
    isLiked: true,
    hasMusic: true,
    difficulty: 'Beginner',
    tags: ['sunrise', 'mandala', 'dawn', 'light']
  }
];

const leaderboard = [
  { rank: 1, artist: 'Priya Sharma', points: 2850, badge: '🏆' },
  { rank: 2, artist: 'Classical_Fusion', points: 2640, badge: '🥈' },
  { rank: 3, artist: 'Kolam_Master_2025', points: 2420, badge: '🥉' },
  { rank: 4, artist: 'Meera Krishna', points: 2180, badge: '⭐' },
  { rank: 5, artist: 'Dawn_Artist', points: 1950, badge: '⭐' }
];

export function Gallery({ onNavigate }: GalleryProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [galleryItems, setGalleryItems] = useState(mockGalleryItems);

  const filteredItems = galleryItems.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category.toLowerCase() === selectedCategory;
    const matchesSearch = searchQuery === '' || 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    return matchesCategory && matchesSearch;
  });

  const handleLike = (id: string) => {
    setGalleryItems(items => 
      items.map(item => 
        item.id === id 
          ? { 
              ...item, 
              isLiked: !item.isLiked, 
              likes: item.isLiked ? item.likes - 1 : item.likes + 1 
            }
          : item
      )
    );
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-800';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'Advanced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Traditional': return 'bg-orange-100 text-orange-800';
      case 'Musical': return 'bg-purple-100 text-purple-800';
      case 'Community': return 'bg-blue-100 text-blue-800';
      case 'Challenge': return 'bg-emerald-100 text-emerald-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-orange-50 to-emerald-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Community Gallery</h1>
          <p className="text-lg text-gray-600">Discover and share beautiful Kolam artwork from artists around the world</p>
        </div>

        <Tabs defaultValue="gallery" className="w-full">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto mb-8">
            <TabsTrigger value="gallery">Gallery</TabsTrigger>
            <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
          </TabsList>

          <TabsContent value="gallery" className="space-y-6">
            {/* Search and Filters */}
            <Card className="p-6">
              <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
                <div className="flex-1 max-w-md">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search by title, artist, or tags..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  {/* Category Filter */}
                  <div className="flex items-center space-x-2">
                    <Filter className="w-4 h-4 text-gray-500" />
                    <select
                      value={selectedCategory}
                      onChange={(e) => setSelectedCategory(e.target.value)}
                      className="border border-gray-300 rounded-md px-3 py-2 text-sm"
                    >
                      <option value="all">All Categories</option>
                      <option value="traditional">Traditional</option>
                      <option value="musical">Musical</option>
                      <option value="community">Community</option>
                      <option value="challenge">Challenge</option>
                    </select>
                  </div>

                  {/* View Mode Toggle */}
                  <div className="flex border border-gray-300 rounded-md">
                    <Button
                      variant={viewMode === 'grid' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setViewMode('grid')}
                      className="rounded-r-none"
                    >
                      <Grid3X3 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant={viewMode === 'list' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setViewMode('list')}
                      className="rounded-l-none"
                    >
                      <List className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>

            {/* Gallery Grid/List */}
            <div className={
              viewMode === 'grid' 
                ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
                : 'space-y-4'
            }>
              {filteredItems.map((item) => (
                <Card key={item.id} className={`overflow-hidden hover:shadow-lg transition-shadow ${
                  viewMode === 'list' ? 'p-4' : ''
                }`}>
                  {viewMode === 'grid' ? (
                    <>
                      {/* Grid View */}
                      <div className="aspect-square relative">
                        <ImageWithFallback
                          src={item.image}
                          alt={item.title}
                          className="w-full h-full object-cover"
                        />
                        {item.hasMusic && (
                          <div className="absolute top-2 right-2">
                            <Badge className="bg-purple-500 text-white">
                              <Music className="w-3 h-3 mr-1" />
                              Musical
                            </Badge>
                          </div>
                        )}
                      </div>
                      <div className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold text-gray-900 text-lg">{item.title}</h3>
                          <Badge className={getCategoryColor(item.category)}>
                            {item.category}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">by {item.artist}</p>
                        <p className="text-sm text-gray-700 mb-3 line-clamp-2">{item.description}</p>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <button
                              onClick={() => handleLike(item.id)}
                              className={`flex items-center space-x-1 transition-colors ${
                                item.isLiked ? 'text-red-500' : 'hover:text-red-500'
                              }`}
                            >
                              <Heart className={`w-4 h-4 ${item.isLiked ? 'fill-current' : ''}`} />
                              <span>{item.likes}</span>
                            </button>
                            <div className="flex items-center space-x-1">
                              <MessageCircle className="w-4 h-4" />
                              <span>{item.comments}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Eye className="w-4 h-4" />
                              <span>View</span>
                            </div>
                          </div>
                          <Badge className={getDifficultyColor(item.difficulty)} size="sm">
                            {item.difficulty}
                          </Badge>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="flex space-x-4">
                      {/* List View */}
                      <div className="w-24 h-24 rounded-lg overflow-hidden flex-shrink-0">
                        <ImageWithFallback
                          src={item.image}
                          alt={item.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-gray-900">{item.title}</h3>
                            <p className="text-sm text-gray-600">by {item.artist} • {item.createdAt}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className={getCategoryColor(item.category)} size="sm">
                              {item.category}
                            </Badge>
                            {item.hasMusic && (
                              <Badge className="bg-purple-500 text-white" size="sm">
                                <Music className="w-3 h-3" />
                              </Badge>
                            )}
                          </div>
                        </div>
                        <p className="text-sm text-gray-700 mb-3">{item.description}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <button
                              onClick={() => handleLike(item.id)}
                              className={`flex items-center space-x-1 transition-colors ${
                                item.isLiked ? 'text-red-500' : 'hover:text-red-500'
                              }`}
                            >
                              <Heart className={`w-4 h-4 ${item.isLiked ? 'fill-current' : ''}`} />
                              <span>{item.likes}</span>
                            </button>
                            <div className="flex items-center space-x-1">
                              <MessageCircle className="w-4 h-4" />
                              <span>{item.comments}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Share2 className="w-4 h-4" />
                              <span>Share</span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge className={getDifficultyColor(item.difficulty)} size="sm">
                              {item.difficulty}
                            </Badge>
                            <Button variant="outline" size="sm">
                              <Download className="w-3 h-3 mr-1" />
                              Save
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </Card>
              ))}
            </div>

            {filteredItems.length === 0 && (
              <Card className="p-12 text-center">
                <div className="text-gray-400 mb-4">
                  <Search className="w-16 h-16 mx-auto" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No Results Found</h3>
                <p className="text-gray-600">Try adjusting your search or filter criteria</p>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="leaderboard" className="space-y-6">
            {/* Leaderboard */}
            <Card className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Community Leaderboard
              </h2>
              
              <div className="space-y-4">
                {leaderboard.map((user) => (
                  <div
                    key={user.rank}
                    className={`flex items-center justify-between p-4 rounded-lg border-2 ${
                      user.rank <= 3 
                        ? 'border-yellow-300 bg-yellow-50' 
                        : 'border-gray-200 bg-white'
                    }`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className="text-2xl">{user.badge}</div>
                      <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-red-500 rounded-full flex items-center justify-center text-white font-bold">
                        {user.rank}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{user.artist}</h3>
                        <p className="text-sm text-gray-600">{user.points} points</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm">
                        <User className="w-4 h-4 mr-2" />
                        View Profile
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 text-center">
                <Card className="p-6 bg-gradient-to-r from-orange-50 to-emerald-50 border-orange-200">
                  <Trophy className="w-12 h-12 mx-auto mb-4 text-orange-600" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Join the Competition!</h3>
                  <p className="text-gray-600 mb-4">
                    Earn points by creating Kolam art, participating in challenges, and engaging with the community.
                  </p>
                  <Button 
                    onClick={() => onNavigate('challenge')}
                    className="bg-gradient-to-r from-orange-500 to-red-500 text-white"
                  >
                    <Trophy className="w-4 h-4 mr-2" />
                    Join Challenge
                  </Button>
                </Card>
              </div>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="mt-12 text-center">
          <div className="inline-flex space-x-4">
            <Button
              onClick={() => onNavigate('create')}
              className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-8 py-3"
              size="lg"
            >
              Create Your Art
            </Button>
            <Button
              onClick={() => onNavigate('challenge')}
              variant="outline"
              className="border-2 border-orange-500 text-orange-700 px-8 py-3"
              size="lg"
            >
              <Clock className="w-5 h-5 mr-2" />
              Daily Challenge
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}