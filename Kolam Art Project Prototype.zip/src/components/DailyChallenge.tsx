import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  Calendar, 
  Clock, 
  Trophy, 
  Star, 
  Play, 
  CheckCircle, 
  Gift,
  Users,
  Target,
  Zap,
  Award,
  Timer
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import type { Page } from '../App';

interface DailyChallengeProps {
  onNavigate: (page: Page) => void;
}

interface Challenge {
  id: string;
  day: number;
  title: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  timeLimit: number; // in minutes
  points: number;
  pattern: string;
  image: string;
  isCompleted: boolean;
  isActive: boolean;
  unlockDate: string;
  completedBy: number;
  musicReward: string;
}

const challenges: Challenge[] = [
  {
    id: '1',
    day: 1,
    title: 'First Steps',
    description: 'Create a simple 3x3 dot grid with basic connecting lines',
    difficulty: 'Easy',
    timeLimit: 15,
    points: 100,
    pattern: 'Basic Grid',
    image: 'https://images.unsplash.com/photo-1703584347443-43e3c50a5a80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb2xhbSUyMHJhbmdvbGklMjB0cmFkaXRpb25hbCUyMGluZGlhbiUyMGFydHxlbnwxfHx8fDE3NTg2NDMwMjF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    isCompleted: true,
    isActive: false,
    unlockDate: 'Jan 1, 2025',
    completedBy: 2847,
    musicReward: 'Peaceful Tanpura Drone'
  },
  {
    id: '2',
    day: 2,
    title: 'Circular Harmony',
    description: 'Draw perfect circles around each dot in a symmetrical pattern',
    difficulty: 'Easy',
    timeLimit: 20,
    points: 150,
    pattern: 'Circle Pattern',
    image: 'https://images.unsplash.com/photo-1571015691553-6f6bbd4ad1d6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnZW9tZXRyaWMlMjBwYXR0ZXJucyUyMG1hbmRhbGElMjBzYWNyZWQlMjBnZW9tZXRyeXxlbnwxfHx8fDE3NTg2NDMwMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    isCompleted: true,
    isActive: false,
    unlockDate: 'Jan 2, 2025',
    completedBy: 2156,
    musicReward: 'Gentle Flute Melody'
  },
  {
    id: '15',
    day: 15,
    title: 'Floral Symmetry',
    description: 'Create a beautiful flower pattern with perfect 8-fold symmetry',
    difficulty: 'Medium',
    timeLimit: 30,
    points: 250,
    pattern: 'Flower Mandala',
    image: 'https://images.unsplash.com/photo-1664427650948-edaa97ea4dd5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjB0ZW1wbGUlMjBhcmNoaXRlY3R1cmUlMjBjdWx0dXJhbCUyMGhlcml0YWdlfGVufDF8fHx8MTc1ODY0MzAyM3ww&ixlib=rb-4.1.0&q=80&w=1080',
    isCompleted: false,
    isActive: true,
    unlockDate: 'Today',
    completedBy: 892,
    musicReward: 'Raga Yaman Composition'
  },
  {
    id: '16',
    day: 16,
    title: 'Musical Waves',
    description: 'Design a pattern that creates wave-like musical rhythms',
    difficulty: 'Medium',
    timeLimit: 35,
    points: 300,
    pattern: 'Wave Pattern',
    image: 'https://images.unsplash.com/photo-1643098979608-1b22614abe88?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBjbGFzc2ljYWwlMjBtdXNpYyUyMGluc3RydW1lbnRzJTIwdmVlbmElMjBzaXRhcnxlbnwxfHx8fDE3NTg2NDMwMjJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    isCompleted: false,
    isActive: false,
    unlockDate: 'Tomorrow',
    completedBy: 0,
    musicReward: 'Tabla & Sitar Fusion'
  },
  {
    id: '30',
    day: 30,
    title: 'Master\'s Challenge',
    description: 'The ultimate test - create a complex traditional temple pattern',
    difficulty: 'Hard',
    timeLimit: 60,
    points: 500,
    pattern: 'Temple Complex',
    image: 'https://images.unsplash.com/photo-1703584347443-43e3c50a5a80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb2xhbSUyMHJhbmdvbGklMjB0cmFkaXRpb25hbCUyMGluZGlhbiUyMGFydHxlbnwxfHx8fDE3NTg2NDMwMjF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    isCompleted: false,
    isActive: false,
    unlockDate: 'Jan 30, 2025',
    completedBy: 0,
    musicReward: 'Grand Classical Orchestra'
  }
];

export function DailyChallenge({ onNavigate }: DailyChallengeProps) {
  const [currentChallenge, setCurrentChallenge] = useState(challenges.find(c => c.isActive) || challenges[2]);
  const [timeRemaining, setTimeRemaining] = useState(23 * 3600 + 45 * 60 + 30); // 23h 45m 30s
  const [userProgress, setUserProgress] = useState({
    streak: 7,
    totalPoints: 1250,
    completedChallenges: 14,
    rank: 156
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeRemaining(prev => Math.max(0, prev - 1));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-800';
      case 'Medium': return 'bg-yellow-100 text-yellow-800';
      case 'Hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleStartChallenge = () => {
    // In a real app, this would start the challenge timer and open create mode
    onNavigate('create');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-yellow-50 to-emerald-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Daily Kolam Challenge</h1>
          <p className="text-lg text-gray-600">Push your creativity with daily pattern challenges and earn musical rewards</p>
        </div>

        {/* User Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-4 text-center">
            <Zap className="w-8 h-8 mx-auto mb-2 text-orange-600" />
            <div className="text-2xl font-bold text-gray-900">{userProgress.streak}</div>
            <div className="text-sm text-gray-600">Day Streak</div>
          </Card>
          <Card className="p-4 text-center">
            <Star className="w-8 h-8 mx-auto mb-2 text-yellow-600" />
            <div className="text-2xl font-bold text-gray-900">{userProgress.totalPoints}</div>
            <div className="text-sm text-gray-600">Total Points</div>
          </Card>
          <Card className="p-4 text-center">
            <CheckCircle className="w-8 h-8 mx-auto mb-2 text-green-600" />
            <div className="text-2xl font-bold text-gray-900">{userProgress.completedChallenges}</div>
            <div className="text-sm text-gray-600">Completed</div>
          </Card>
          <Card className="p-4 text-center">
            <Trophy className="w-8 h-8 mx-auto mb-2 text-purple-600" />
            <div className="text-2xl font-bold text-gray-900">#{userProgress.rank}</div>
            <div className="text-sm text-gray-600">Global Rank</div>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Today's Challenge */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="p-8 border-2 border-orange-300 bg-gradient-to-br from-orange-50 to-yellow-50">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-500 rounded-full flex items-center justify-center text-white font-bold">
                    {currentChallenge.day}
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{currentChallenge.title}</h2>
                    <p className="text-gray-600">Day {currentChallenge.day} Challenge</p>
                  </div>
                </div>
                <Badge className={getDifficultyColor(currentChallenge.difficulty)}>
                  {currentChallenge.difficulty}
                </Badge>
              </div>

              <div className="aspect-video rounded-lg overflow-hidden mb-6">
                <ImageWithFallback
                  src={currentChallenge.image}
                  alt={currentChallenge.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Challenge Description</h3>
                  <p className="text-gray-700">{currentChallenge.description}</p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Pattern Type:</span>
                    <div className="font-medium">{currentChallenge.pattern}</div>
                  </div>
                  <div>
                    <span className="text-gray-500">Time Limit:</span>
                    <div className="font-medium">{currentChallenge.timeLimit} minutes</div>
                  </div>
                  <div>
                    <span className="text-gray-500">Points:</span>
                    <div className="font-medium text-orange-600">{currentChallenge.points} pts</div>
                  </div>
                  <div>
                    <span className="text-gray-500">Participants:</span>
                    <div className="font-medium">{currentChallenge.completedBy.toLocaleString()}</div>
                  </div>
                </div>

                <div className="bg-purple-50 rounded-lg p-4">
                  <div className="flex items-center mb-2">
                    <Gift className="w-5 h-5 mr-2 text-purple-600" />
                    <span className="font-semibold text-purple-900">Musical Reward</span>
                  </div>
                  <p className="text-purple-800">{currentChallenge.musicReward}</p>
                </div>

                <div className="flex items-center justify-between pt-4">
                  <div className="flex items-center space-x-2 text-gray-600">
                    <Timer className="w-5 h-5" />
                    <span>Time remaining: {formatTime(timeRemaining)}</span>
                  </div>
                  
                  <div className="flex space-x-3">
                    <Button
                      variant="outline"
                      onClick={() => onNavigate('gallery')}
                    >
                      <Users className="w-4 h-4 mr-2" />
                      View Submissions
                    </Button>
                    <Button
                      onClick={handleStartChallenge}
                      className="bg-gradient-to-r from-orange-500 to-red-500 text-white"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Start Challenge
                    </Button>
                  </div>
                </div>
              </div>
            </Card>

            {/* Progress Tracking */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">This Month's Progress</h3>
              
              <div className="mb-4">
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Challenge Completion</span>
                  <span>{userProgress.completedChallenges}/30</span>
                </div>
                <Progress value={(userProgress.completedChallenges / 30) * 100} className="h-3" />
              </div>

              <div className="grid grid-cols-7 gap-2">
                {Array.from({ length: 30 }, (_, i) => {
                  const dayNumber = i + 1;
                  const challenge = challenges.find(c => c.day === dayNumber);
                  const isCompleted = challenge?.isCompleted || dayNumber < 15;
                  const isActive = challenge?.isActive || dayNumber === 15;
                  const isLocked = dayNumber > 16;

                  return (
                    <div
                      key={i}
                      className={`aspect-square rounded-lg flex items-center justify-center text-xs font-medium ${
                        isCompleted
                          ? 'bg-green-100 text-green-800'
                          : isActive
                          ? 'bg-orange-100 text-orange-800 border-2 border-orange-300'
                          : isLocked
                          ? 'bg-gray-100 text-gray-400'
                          : 'bg-blue-100 text-blue-800'
                      }`}
                    >
                      {isCompleted ? <CheckCircle className="w-3 h-3" /> : dayNumber}
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Challenge History */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Challenges</h3>
              <div className="space-y-4">
                {challenges.filter(c => c.isCompleted).slice(-3).map((challenge) => (
                  <div key={challenge.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className="w-12 h-12 rounded-lg overflow-hidden">
                      <ImageWithFallback
                        src={challenge.image}
                        alt={challenge.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 text-sm">{challenge.title}</h4>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge className="bg-green-100 text-green-800" size="sm">
                          Completed
                        </Badge>
                        <span className="text-xs text-gray-600">+{challenge.points} pts</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Tips & Strategies */}
            <Card className="p-6 bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <Target className="w-5 h-5 mr-2 text-emerald-600" />
                Pro Tips
              </h3>
              <ul className="space-y-3 text-sm text-gray-700">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Practice the pattern type in Learn mode before attempting the challenge</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Use symmetry mode to ensure perfect balance in your designs</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Complete challenges early to maximize your daily streak bonus</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                  <span>Listen to your musical creation after completing each challenge</span>
                </li>
              </ul>
            </Card>

            {/* Upcoming Rewards */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                <Award className="w-5 h-5 mr-2 text-yellow-600" />
                Upcoming Rewards
              </h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">15-Day Streak</div>
                    <div className="text-sm text-gray-600">Unlock new color palette</div>
                  </div>
                  <Badge className="bg-yellow-200 text-yellow-800">1 day left</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">1500 Points</div>
                    <div className="text-sm text-gray-600">Premium instrument sounds</div>
                  </div>
                  <Badge variant="outline">250 pts to go</Badge>
                </div>
                <div className="flex items-center justify-between p-3 bg-emerald-50 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">Month Complete</div>
                    <div className="text-sm text-gray-600">Master Creator Badge</div>
                  </div>
                  <Badge variant="outline">16 days left</Badge>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-12 text-center">
          <div className="inline-flex space-x-4">
            <Button
              onClick={() => onNavigate('learn')}
              variant="outline"
              className="border-2 border-emerald-500 text-emerald-700 px-8 py-3"
              size="lg"
            >
              Practice First
            </Button>
            <Button
              onClick={() => onNavigate('gallery')}
              variant="outline"
              className="border-2 border-purple-500 text-purple-700 px-8 py-3"
              size="lg"
            >
              <Users className="w-5 h-5 mr-2" />
              View Community
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}