import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { PlayCircle, PauseCircle, SkipForward, SkipBack, Volume2, Book, Star } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { TutorialStep } from './TutorialStep';
import type { Page } from '../App';

interface LearnKolamProps {
  onNavigate: (page: Page) => void;
}

const tutorials = [
  {
    id: 1,
    title: "Basic Dots Pattern",
    description: "Learn to create the foundation grid of dots",
    difficulty: "Beginner",
    duration: "5 min",
    cultural_context: "The dot grid (pulli) represents the cosmic order and serves as the foundation for all Kolam patterns. Each dot symbolizes a star in the universe.",
    steps: [
      "Place dots in a regular grid pattern",
      "Maintain equal spacing between dots",
      "Start with a 3x3 grid for beginners",
      "Ensure dots are clearly visible"
    ],
    completed: false
  },
  {
    id: 2,
    title: "Simple Loop Patterns",
    description: "Connect dots with curved lines to form loops",
    difficulty: "Beginner",
    duration: "8 min",
    cultural_context: "Loops in Kolam represent the cycle of life and the continuity of existence. The unbroken line symbolizes the eternal nature of the soul.",
    steps: [
      "Start from the center dot",
      "Draw curved lines connecting adjacent dots",
      "Create closed loops around dot clusters",
      "Maintain symmetry in your pattern"
    ],
    completed: false
  },
  {
    id: 3,
    title: "Geometric Symmetry",
    description: "Master the art of perfect symmetrical designs",
    difficulty: "Intermediate",
    duration: "12 min",
    cultural_context: "Symmetry in Kolam reflects the balance and harmony in nature. It represents the order that underlies apparent chaos in the universe.",
    steps: [
      "Establish central axis lines",
      "Mirror patterns on both sides",
      "Use rotational symmetry for complex designs",
      "Check alignment at each step"
    ],
    completed: false
  },
  {
    id: 4,
    title: "Traditional Motifs",
    description: "Learn classic symbols like lotus, peacock, and sun",
    difficulty: "Intermediate",
    duration: "15 min",
    cultural_context: "Traditional motifs carry deep spiritual meaning. The lotus represents purity, the peacock symbolizes grace, and the sun signifies knowledge and enlightenment.",
    steps: [
      "Study the symbolic meaning",
      "Break complex motifs into simple shapes",
      "Practice individual elements first",
      "Combine elements into complete motifs"
    ],
    completed: false
  },
  {
    id: 5,
    title: "Advanced Compositions",
    description: "Create complex multi-layer Kolam designs",
    difficulty: "Advanced",
    duration: "20 min", 
    cultural_context: "Advanced Kolam compositions tell stories and convey complex philosophical concepts. They often represent the interconnectedness of all life.",
    steps: [
      "Plan your composition layout",
      "Layer multiple pattern types",
      "Maintain visual hierarchy",
      "Balance complexity with clarity"
    ],
    completed: false
  }
];

export function LearnKolam({ onNavigate }: LearnKolamProps) {
  const [selectedTutorial, setSelectedTutorial] = useState(tutorials[0]);
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  const completedCount = tutorials.filter(t => t.completed).length;
  const overallProgress = (completedCount / tutorials.length) * 100;

  const handleStepComplete = () => {
    if (currentStep < selectedTutorial.steps.length - 1) {
      setCurrentStep(currentStep + 1);
      setProgress(((currentStep + 1) / selectedTutorial.steps.length) * 100);
    } else {
      // Tutorial completed
      const updatedTutorials = tutorials.map(t => 
        t.id === selectedTutorial.id ? { ...t, completed: true } : t
      );
      setProgress(100);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-green-100 text-green-800';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'Advanced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-orange-50 to-emerald-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">Learn Kolam</h1>
              <p className="text-lg text-gray-600">Master the ancient art through interactive tutorials</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-orange-600">{completedCount}/{tutorials.length}</div>
              <div className="text-sm text-gray-500">Tutorials Completed</div>
            </div>
          </div>
          
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Overall Progress</span>
              <span className="text-sm text-gray-500">{Math.round(overallProgress)}%</span>
            </div>
            <Progress value={overallProgress} className="h-2" />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Tutorial List */}
          <div className="lg:col-span-1">
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-4 text-gray-900">Tutorial Modules</h2>
              <div className="space-y-3">
                {tutorials.map((tutorial) => (
                  <div
                    key={tutorial.id}
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedTutorial.id === tutorial.id
                        ? 'border-orange-500 bg-orange-50'
                        : 'border-gray-200 hover:border-orange-300'
                    }`}
                    onClick={() => {
                      setSelectedTutorial(tutorial);
                      setCurrentStep(0);
                      setProgress(0);
                    }}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-medium text-gray-900">{tutorial.title}</h3>
                      {tutorial.completed && (
                        <Star className="w-5 h-5 text-yellow-500 fill-current" />
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{tutorial.description}</p>
                    <div className="flex items-center justify-between">
                      <Badge className={getDifficultyColor(tutorial.difficulty)}>
                        {tutorial.difficulty}
                      </Badge>
                      <span className="text-xs text-gray-500">{tutorial.duration}</span>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Main Tutorial Content */}
          <div className="lg:col-span-2">
            <Card className="p-8">
              <div className="mb-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-2xl font-bold text-gray-900">{selectedTutorial.title}</h2>
                  <Badge className={getDifficultyColor(selectedTutorial.difficulty)}>
                    {selectedTutorial.difficulty}
                  </Badge>
                </div>
                
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-700">
                      Step {currentStep + 1} of {selectedTutorial.steps.length}
                    </span>
                    <span className="text-sm text-gray-500">{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
              </div>

              {/* Tutorial Step Component */}
              <TutorialStep
                step={selectedTutorial.steps[currentStep]}
                stepNumber={currentStep + 1}
                totalSteps={selectedTutorial.steps.length}
                onComplete={handleStepComplete}
              />

              {/* Controls */}
              <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
                <div className="flex items-center space-x-4">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                    disabled={currentStep === 0}
                  >
                    <SkipBack className="w-4 h-4 mr-2" />
                    Previous
                  </Button>
                  
                  <Button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="bg-gradient-to-r from-orange-500 to-red-500 text-white"
                  >
                    {isPlaying ? (
                      <PauseCircle className="w-4 h-4 mr-2" />
                    ) : (
                      <PlayCircle className="w-4 h-4 mr-2" />
                    )}
                    {isPlaying ? 'Pause' : 'Play'} Narration
                  </Button>
                  
                  <Button variant="outline">
                    <Volume2 className="w-4 h-4 mr-2" />
                    Background Music
                  </Button>
                </div>

                <Button
                  onClick={handleStepComplete}
                  disabled={currentStep === selectedTutorial.steps.length - 1 && progress === 100}
                >
                  <SkipForward className="w-4 h-4 mr-2" />
                  Next Step
                </Button>
              </div>
            </Card>

            {/* Cultural Context Card */}
            <Card className="p-6 mt-6 border-l-4 border-l-emerald-500">
              <div className="flex items-start space-x-3">
                <Book className="w-6 h-6 text-emerald-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Cultural Context</h3>
                  <p className="text-gray-700 leading-relaxed">{selectedTutorial.cultural_context}</p>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-12 text-center">
          <div className="inline-flex space-x-4">
            <Button
              onClick={() => onNavigate('create')}
              className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-8 py-3"
              size="lg"
            >
              Practice in Create Mode
            </Button>
            <Button
              onClick={() => onNavigate('challenge')}
              variant="outline"
              className="border-2 border-orange-500 text-orange-700 px-8 py-3"
              size="lg"
            >
              Try Today's Challenge
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}