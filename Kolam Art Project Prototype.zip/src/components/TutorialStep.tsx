import { useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { CheckCircle, Circle, Play } from 'lucide-react';
import { motion } from 'motion/react';

interface TutorialStepProps {
  step: string;
  stepNumber: number;
  totalSteps: number;
  onComplete: () => void;
}

export function TutorialStep({ step, stepNumber, totalSteps, onComplete }: TutorialStepProps) {
  const [isCompleted, setIsCompleted] = useState(false);

  const handleComplete = () => {
    setIsCompleted(true);
    setTimeout(() => {
      onComplete();
      setIsCompleted(false);
    }, 1000);
  };

  return (
    <div className="space-y-6">
      {/* Interactive Canvas Area */}
      <Card className="p-8 bg-gradient-to-br from-gray-50 to-white border-2 border-dashed border-gray-300">
        <div className="aspect-video flex items-center justify-center">
          <KolamStepVisualization stepNumber={stepNumber} />
        </div>
      </Card>

      {/* Step Instructions */}
      <div className="bg-white rounded-lg p-6 border border-gray-200">
        <div className="flex items-start space-x-4">
          <div className="flex-shrink-0">
            <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-500 rounded-full flex items-center justify-center text-white font-semibold">
              {stepNumber}
            </div>
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Step {stepNumber}: {step}
            </h3>
            <p className="text-gray-600 mb-4">
              Follow along with the visual demonstration above. Take your time to understand each movement and pattern.
            </p>
            
            {/* Practice Area */}
            <div className="bg-orange-50 rounded-lg p-4 mb-4">
              <h4 className="font-medium text-orange-900 mb-2">Practice Tips:</h4>
              <ul className="text-sm text-orange-800 space-y-1">
                <li>• Start slowly and focus on accuracy over speed</li>
                <li>• Maintain consistent spacing between elements</li>
                <li>• Use light pressure when drawing initial guides</li>
                <li>• Practice the motion several times before committing</li>
              </ul>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <Circle className="w-4 h-4" />
                <span>Practice this step</span>
              </div>
              
              <Button
                onClick={handleComplete}
                disabled={isCompleted}
                className={`transition-all duration-300 ${
                  isCompleted 
                    ? 'bg-green-500 text-white' 
                    : 'bg-gradient-to-r from-orange-500 to-red-500 text-white hover:from-orange-600 hover:to-red-600'
                }`}
              >
                {isCompleted ? (
                  <>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Completed!
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Mark as Complete
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function KolamStepVisualization({ stepNumber }: { stepNumber: number }) {
  const renderStep = () => {
    switch (stepNumber) {
      case 1:
        return <DotGridVisualization />;
      case 2:
        return <LoopPatternVisualization />;
      case 3:
        return <SymmetryVisualization />;
      case 4:
        return <MotifVisualization />;
      default:
        return <DotGridVisualization />;
    }
  };

  return (
    <div className="w-full h-full flex items-center justify-center">
      {renderStep()}
    </div>
  );
}

function DotGridVisualization() {
  const dots = Array.from({ length: 25 }, (_, i) => ({
    id: i,
    x: (i % 5) * 40 + 50,
    y: Math.floor(i / 5) * 40 + 50,
  }));

  return (
    <svg width="250" height="250" viewBox="0 0 250 250">
      {dots.map((dot, index) => (
        <motion.circle
          key={dot.id}
          cx={dot.x}
          cy={dot.y}
          r="4"
          fill="#f97316"
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{
            duration: 0.3,
            delay: index * 0.1,
          }}
        />
      ))}
    </svg>
  );
}

function LoopPatternVisualization() {
  return (
    <svg width="250" height="250" viewBox="0 0 250 250">
      {/* Dots */}
      {Array.from({ length: 9 }, (_, i) => (
        <circle
          key={i}
          cx={(i % 3) * 80 + 70}
          cy={Math.floor(i / 3) * 80 + 70}
          r="3"
          fill="#6b7280"
        />
      ))}
      
      {/* Animated loop */}
      <motion.path
        d="M 70 70 Q 125 45 150 70 Q 175 95 150 150 Q 125 175 70 150 Q 45 125 70 70"
        fill="none"
        stroke="#f97316"
        strokeWidth="3"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 2, delay: 0.5 }}
      />
    </svg>
  );
}

function SymmetryVisualization() {
  return (
    <svg width="250" height="250" viewBox="0 0 250 250">
      {/* Center line */}
      <line x1="125" y1="0" x2="125" y2="250" stroke="#e5e7eb" strokeWidth="1" strokeDasharray="5,5" />
      
      {/* Left side pattern */}
      <motion.path
        d="M 50 50 L 100 100 L 50 150 L 100 200"
        fill="none"
        stroke="#f97316"
        strokeWidth="3"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 1.5 }}
      />
      
      {/* Right side pattern (mirrored) */}
      <motion.path
        d="M 200 50 L 150 100 L 200 150 L 150 200"
        fill="none"
        stroke="#f97316"
        strokeWidth="3"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 1.5, delay: 0.5 }}
      />
    </svg>
  );
}

function MotifVisualization() {
  return (
    <svg width="250" height="250" viewBox="0 0 250 250">
      {/* Lotus petals */}
      {Array.from({ length: 8 }, (_, i) => (
        <motion.ellipse
          key={i}
          cx="125"
          cy="80"
          rx="15"
          ry="30"
          fill="#f97316"
          opacity="0.7"
          transform={`rotate(${i * 45} 125 125)`}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: i * 0.1 }}
        />
      ))}
      
      {/* Center circle */}
      <motion.circle
        cx="125"
        cy="125"
        r="15"
        fill="#dc2626"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, delay: 0.8 }}
      />
    </svg>
  );
}