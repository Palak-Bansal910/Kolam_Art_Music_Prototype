import { useRef, useEffect, useState, useCallback } from 'react';

interface KolamCanvasProps {
  tool: 'dot' | 'line' | 'brush' | 'eraser';
  color: string;
  brushSize: number;
  showGrid: boolean;
  symmetryMode: boolean;
  onDrawAction: (x: number, y: number) => void;
  musicEnabled: boolean;
}

interface Point {
  x: number;
  y: number;
}

export function KolamCanvas({
  tool,
  color,
  brushSize,
  showGrid,
  symmetryMode,
  onDrawAction,
  musicEnabled
}: KolamCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [lastPoint, setLastPoint] = useState<Point | null>(null);
  const [dots, setDots] = useState<Point[]>([]);

  const gridSize = 20;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * window.devicePixelRatio;
    canvas.height = rect.height * window.devicePixelRatio;
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw grid if enabled
    if (showGrid) {
      drawGrid(ctx, rect.width, rect.height);
    }

    // Redraw dots
    dots.forEach(dot => {
      drawDot(ctx, dot.x, dot.y, 4, '#6b7280');
    });
  }, [showGrid, dots]);

  const drawGrid = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 0.5;
    ctx.setLineDash([2, 2]);

    // Vertical lines
    for (let x = gridSize; x < width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    // Horizontal lines
    for (let y = gridSize; y < height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    ctx.setLineDash([]);
  };

  const drawDot = (ctx: CanvasRenderingContext2D, x: number, y: number, radius: number, fillColor: string) => {
    ctx.fillStyle = fillColor;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, 2 * Math.PI);
    ctx.fill();
  };

  const drawLine = (ctx: CanvasRenderingContext2D, from: Point, to: Point, strokeColor: string, lineWidth: number) => {
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = lineWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(to.x, to.y);
    ctx.stroke();
  };

  const snapToGrid = (point: Point): Point => {
    return {
      x: Math.round(point.x / gridSize) * gridSize,
      y: Math.round(point.y / gridSize) * gridSize
    };
  };

  const getCanvasPoint = (event: React.MouseEvent<HTMLCanvasElement>): Point => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };

    const rect = canvas.getBoundingClientRect();
    return {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    };
  };

  const handleMouseDown = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const point = getCanvasPoint(event);
    const snappedPoint = tool === 'dot' ? snapToGrid(point) : point;

    setIsDrawing(true);
    setLastPoint(snappedPoint);

    if (tool === 'dot') {
      // Add dot
      setDots(prev => [...prev, snappedPoint]);
      drawDot(ctx, snappedPoint.x, snappedPoint.y, brushSize / 2, color);
      
      // Play musical note
      if (musicEnabled) {
        onDrawAction(snappedPoint.x, snappedPoint.y);
      }

      // Draw symmetrical dot if symmetry mode is enabled
      if (symmetryMode) {
        const centerX = canvas.offsetWidth / 2;
        const symmetricalPoint = {
          x: centerX + (centerX - snappedPoint.x),
          y: snappedPoint.y
        };
        setDots(prev => [...prev, symmetricalPoint]);
        drawDot(ctx, symmetricalPoint.x, symmetricalPoint.y, brushSize / 2, color);
      }
    }
  };

  const handleMouseMove = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !lastPoint) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const point = getCanvasPoint(event);

    if (tool === 'line' || tool === 'brush') {
      drawLine(ctx, lastPoint, point, color, brushSize);
      
      // Play musical note for line drawing
      if (musicEnabled) {
        onDrawAction(point.x, point.y);
      }

      // Draw symmetrical line if symmetry mode is enabled
      if (symmetryMode) {
        const centerX = canvas.offsetWidth / 2;
        const symmetricalLastPoint = {
          x: centerX + (centerX - lastPoint.x),
          y: lastPoint.y
        };
        const symmetricalPoint = {
          x: centerX + (centerX - point.x),
          y: point.y
        };
        drawLine(ctx, symmetricalLastPoint, symmetricalPoint, color, brushSize);
      }

      setLastPoint(point);
    } else if (tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.beginPath();
      ctx.arc(point.x, point.y, brushSize, 0, 2 * Math.PI);
      ctx.fill();
      ctx.globalCompositeOperation = 'source-over';
      setLastPoint(point);
    }
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
    setLastPoint(null);
  };

  return (
    <div className="w-full h-96 relative">
      <canvas
        ref={canvasRef}
        className="w-full h-full cursor-crosshair border border-gray-200 rounded-lg"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />
      
      {/* Tool indicator */}
      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 shadow-sm">
        <div className="flex items-center space-x-2 text-sm">
          <div
            className="w-4 h-4 rounded-full border border-gray-300"
            style={{ backgroundColor: tool === 'eraser' ? '#ef4444' : color }}
          />
          <span className="font-medium">
            {tool.charAt(0).toUpperCase() + tool.slice(1)} - {brushSize}px
          </span>
        </div>
      </div>

      {/* Symmetry indicator */}
      {symmetryMode && (
        <div className="absolute top-4 right-4 bg-purple-100 text-purple-800 rounded-lg px-3 py-2 shadow-sm">
          <div className="flex items-center space-x-2 text-sm font-medium">
            <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse" />
            <span>Symmetry Mode</span>
          </div>
        </div>
      )}

      {/* Center line for symmetry mode */}
      {symmetryMode && (
        <div 
          className="absolute top-0 bottom-0 w-0.5 bg-purple-300 opacity-50 pointer-events-none"
          style={{ left: '50%', transform: 'translateX(-50%)' }}
        />
      )}
    </div>
  );
}