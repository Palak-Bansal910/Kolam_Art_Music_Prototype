import { useEffect, useState } from 'react';
import { motion } from 'motion/react';

interface Dot {
  x: number;
  y: number;
  id: number;
}

interface Line {
  from: Dot;
  to: Dot;
  id: number;
}

export function AnimatedKolamPattern() {
  const [dots, setDots] = useState<Dot[]>([]);
  const [lines, setLines] = useState<Line[]>([]);

  useEffect(() => {
    // Create a grid of dots for Kolam pattern
    const newDots: Dot[] = [];
    const spacing = 80;
    const cols = 8;
    const rows = 6;
    const offsetX = (window.innerWidth - (cols - 1) * spacing) / 2;
    const offsetY = (window.innerHeight - (rows - 1) * spacing) / 2;

    let id = 0;
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols; col++) {
        newDots.push({
          x: offsetX + col * spacing,
          y: offsetY + row * spacing,
          id: id++
        });
      }
    }
    setDots(newDots);

    // Create connecting lines for traditional Kolam pattern
    const newLines: Line[] = [];
    let lineId = 0;

    // Horizontal connections
    for (let row = 0; row < rows; row++) {
      for (let col = 0; col < cols - 1; col++) {
        const from = newDots[row * cols + col];
        const to = newDots[row * cols + col + 1];
        newLines.push({ from, to, id: lineId++ });
      }
    }

    // Vertical connections
    for (let row = 0; row < rows - 1; row++) {
      for (let col = 0; col < cols; col++) {
        const from = newDots[row * cols + col];
        const to = newDots[(row + 1) * cols + col];
        newLines.push({ from, to, id: lineId++ });
      }
    }

    // Diagonal connections for pattern complexity
    for (let row = 0; row < rows - 1; row++) {
      for (let col = 0; col < cols - 1; col++) {
        if ((row + col) % 2 === 0) {
          const from = newDots[row * cols + col];
          const to = newDots[(row + 1) * cols + col + 1];
          newLines.push({ from, to, id: lineId++ });
        }
      }
    }

    setLines(newLines);
  }, []);

  return (
    <div className="absolute inset-0 overflow-hidden opacity-20">
      <svg width="100%" height="100%" className="absolute inset-0">
        {/* Animated lines */}
        {lines.map((line, index) => (
          <motion.line
            key={line.id}
            x1={line.from.x}
            y1={line.from.y}
            x2={line.to.x}
            y2={line.to.y}
            stroke="url(#kolamGradient)"
            strokeWidth="2"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{
              duration: 2,
              delay: index * 0.1,
              repeat: Infinity,
              repeatType: "reverse",
              repeatDelay: 3
            }}
          />
        ))}

        {/* Animated dots */}
        {dots.map((dot, index) => (
          <motion.circle
            key={dot.id}
            cx={dot.x}
            cy={dot.y}
            r="4"
            fill="url(#kolamGradient)"
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{
              duration: 0.5,
              delay: index * 0.05,
              repeat: Infinity,
              repeatType: "reverse",
              repeatDelay: 4
            }}
          />
        ))}

        {/* Gradient definition */}
        <defs>
          <linearGradient id="kolamGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#f97316" />
            <stop offset="50%" stopColor="#dc2626" />
            <stop offset="100%" stopColor="#059669" />
          </linearGradient>
        </defs>
      </svg>

      {/* Additional floating elements */}
      <div className="absolute inset-0">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-gradient-to-br from-orange-400 to-emerald-400 rounded-full"
            initial={{
              x: Math.random() * window.innerWidth,
              y: Math.random() * window.innerHeight,
            }}
            animate={{
              x: Math.random() * window.innerWidth,
              y: Math.random() * window.innerHeight,
            }}
            transition={{
              duration: 8 + Math.random() * 4,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut"
            }}
          />
        ))}
      </div>
    </div>
  );
}