import { Menu, X, Home, BookOpen, Palette, Camera, Music, Image, Calendar } from 'lucide-react';
import { useState } from 'react';
import { Button } from './ui/button';
import type { Page } from '../App';

interface NavigationProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

export function Navigation({ currentPage, onNavigate }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { id: 'home' as Page, label: 'Home', icon: Home },
    { id: 'learn' as Page, label: 'Learn', icon: BookOpen },
    { id: 'create' as Page, label: 'Create', icon: Palette },
    { id: 'scan' as Page, label: 'Scan', icon: Camera },
    { id: 'music' as Page, label: 'Music', icon: Music },
    { id: 'gallery' as Page, label: 'Gallery', icon: Image },
    { id: 'challenge' as Page, label: 'Challenge', icon: Calendar },
  ];

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-orange-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-emerald-500 rounded-full flex items-center justify-center">
                <div className="w-4 h-4 border-2 border-white rounded-full"></div>
              </div>
              <span className="text-xl font-semibold text-gray-900">Kolam Art</span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Button
                    key={item.id}
                    variant={currentPage === item.id ? "default" : "ghost"}
                    onClick={() => onNavigate(item.id)}
                    className={`px-4 py-2 ${
                      currentPage === item.id 
                        ? 'bg-gradient-to-r from-orange-500 to-emerald-500 text-white' 
                        : 'text-gray-700 hover:text-orange-600'
                    }`}
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {item.label}
                  </Button>
                );
              })}
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                onClick={() => setIsOpen(!isOpen)}
                className="p-2"
              >
                {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden bg-white border-t border-orange-200">
            <div className="px-4 py-2 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Button
                    key={item.id}
                    variant={currentPage === item.id ? "default" : "ghost"}
                    onClick={() => {
                      onNavigate(item.id);
                      setIsOpen(false);
                    }}
                    className={`w-full justify-start ${
                      currentPage === item.id 
                        ? 'bg-gradient-to-r from-orange-500 to-emerald-500 text-white' 
                        : 'text-gray-700'
                    }`}
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {item.label}
                  </Button>
                );
              })}
            </div>
          </div>
        )}
      </nav>
    </>
  );
}