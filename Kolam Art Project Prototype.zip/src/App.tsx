import { useState } from 'react';
import { LandingPage } from './components/LandingPage';
import { LearnKolam } from './components/LearnKolam';
import { CreateKolam } from './components/CreateKolam';
import { ScanKolam } from './components/ScanKolam';
import { MusicExperience } from './components/MusicExperience';
import { Gallery } from './components/Gallery';
import { DailyChallenge } from './components/DailyChallenge';
import { Navigation } from './components/Navigation';

export type Page = 'home' | 'learn' | 'create' | 'scan' | 'music' | 'gallery' | 'challenge';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <LandingPage onNavigate={setCurrentPage} />;
      case 'learn':
        return <LearnKolam onNavigate={setCurrentPage} />;
      case 'create':
        return <CreateKolam onNavigate={setCurrentPage} />;
      case 'scan':
        return <ScanKolam onNavigate={setCurrentPage} />;
      case 'music':
        return <MusicExperience onNavigate={setCurrentPage} />;
      case 'gallery':
        return <Gallery onNavigate={setCurrentPage} />;
      case 'challenge':
        return <DailyChallenge onNavigate={setCurrentPage} />;
      default:
        return <LandingPage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-orange-50 to-emerald-50">
      <Navigation currentPage={currentPage} onNavigate={setCurrentPage} />
      <main className="pt-16">
        {renderPage()}
      </main>
    </div>
  );
}